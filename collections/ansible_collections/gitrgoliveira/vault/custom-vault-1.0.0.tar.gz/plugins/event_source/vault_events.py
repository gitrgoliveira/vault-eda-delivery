
#!/usr/bin/env python3

DOCUMENTATION = """
---
module: vault_events
short_description: HashiCorp Vault WebSocket event source for agentless secret rotation
version_added: "1.0.0"
description:
  - This plugin connects to Vault's WebSocket event streaming endpoint and forwards
    events to ansible-rulebook for processing agentless secret rotation workflows.
  - Supports real-time monitoring of Vault operations including KV secrets,
    database credentials, authentication, and policy changes.
  - Provides automatic reconnection with exponential backoff for reliable monitoring.
  - "IMPORTANT: Requires Vault Enterprise or HCP Vault Dedicated. Event streaming 
    is not available in Vault Community Edition."

options:
  vault_addr:
    description:
      - Vault server URL including protocol and port.
      - Can be provided via VAULT_ADDR environment variable when using --env-vars.
    type: str
    required: true
    example: "http://127.0.0.1:8200"
  
  vault_token:
    description:
      - Vault authentication token with appropriate permissions.
      - Can be provided via VAULT_TOKEN environment variable when using --env-vars.
    type: str
    required: true
    no_log: true
  
  event_paths:
    description:
      - List of event paths to subscribe to.
      - Supports patterns like 'kv-v2/data-*' for wildcard matching.
    type: list
    elements: str
    default: ["kv-v2/data-*"]
    example: ["kv-v2/data-*", "auth/token/*", "sys/policy/*"]
  
  verify_ssl:
    description:
      - Whether to verify SSL certificates for HTTPS connections.
      - Set to false for development environments with self-signed certificates.
    type: bool
    default: true
  
  ping_interval:
    description:
      - WebSocket ping interval in seconds to maintain connection.
    type: int
    default: 20
  
  backoff_initial:
    description:
      - Initial delay in seconds before reconnection attempts.
    type: float
    default: 1.0
  
  backoff_max:
    description:
      - Maximum delay in seconds between reconnection attempts.
    type: float
    default: 30.0
  
  namespace:
    description:
      - Vault namespace for multi-tenant Vault deployments.
    type: str
    required: false
  
  headers:
    description:
      - Additional HTTP headers to include in the WebSocket connection.
    type: dict
    default: {}

requirements:
  - python >= 3.7
  - websockets >= 10.0
  - asyncio
  - HashiCorp Vault Enterprise 1.13+ or HCP Vault Dedicated with event streaming enabled
  - Proper Vault ACL policies for event subscription and secret access

author:
  - Ricardo Oliveira

notes:
  - This plugin requires Vault Enterprise or HCP Vault Dedicated.
  - Event streaming is not available in Vault Community Edition.
  - The plugin automatically handles WebSocket reconnection with exponential backoff.
  - Multiple event paths can be specified to monitor different types of events.
  - Environment variables can be used with ansible-rulebook --env-vars flag.
  - Requires proper ACL policies for both event subscription and secret access.

seealso:
  - name: HashiCorp Vault Event Streaming
    description: Official Vault documentation for event streaming
    link: https://developer.hashicorp.com/vault/api-docs/system/events
  - name: Ansible Event-Driven Automation
    description: Official EDA documentation
    link: https://ansible.readthedocs.io/projects/rulebook/
"""

EXAMPLES = """
# Basic usage with local Vault Enterprise
- name: Monitor local Vault events
  sources:
    - custom.vault.vault_events:
        vault_addr: "http://127.0.0.1:8200"
        vault_token: "myroot"
        event_paths:
          - "kv-v2/data-*"

# Database credential rotation monitoring
- name: Monitor database credential events
  sources:
    - custom.vault.vault_events:
        vault_addr: "{{ ansible_env.VAULT_ADDR }}"
        vault_token: "{{ ansible_env.VAULT_TOKEN }}"
        event_paths:
          - "database/creds-create"
          - "database/rotate"
          - "database/config-*"

# Production setup with SSL and namespace
- name: Monitor production Vault
  sources:
    - custom.vault.vault_events:
        vault_addr: "https://vault.company.com:8200"
        vault_token: "{{ vault_token }}"
        namespace: "production"
        event_paths:
          - "kv-v2/data-*"
          - "database/*"
          - "auth/*"
          - "sys/policy/*"
        verify_ssl: true
        ping_interval: 30

# Environment variable configuration
- name: Monitor with env vars
  sources:
    - custom.vault.vault_events:
        vault_addr: "{{ ansible_env.VAULT_ADDR }}"
        vault_token: "{{ ansible_env.VAULT_TOKEN }}"
        event_paths:
          - "kv-v2/data-*"
          - "database/rotate"

# Development setup with self-signed certs
- name: Development monitoring
  sources:
    - custom.vault.vault_events:
        vault_addr: "https://localhost:8200"
        vault_token: "dev-token"
        verify_ssl: false
        event_paths:
          - "kv-v2/data-*"
"""

"""
HashiCorp Vault WebSocket Event Source Plugin for Ansible Event-Driven Automation

This plugin connects to Vault's WebSocket event streaming endpoint and forwards
events to ansible-rulebook for processing. It supports real-time monitoring of
Vault operations including KV secrets, authentication, and policy changes.

Author: Ricardo Oliveira
License: Mozilla Public License 2.0 (MPL-2.0)
Dependencies: websockets, asyncio
"""

import asyncio
import json
import ssl
import logging
from typing import Any, Dict, List, Optional
from websockets import connect

# Configure logging for the plugin
log = logging.getLogger("vault_events")


async def _stream(queue, url: str, headers: Dict[str, str], ping_interval: int,
                  verify_ssl: bool, backoff_initial: float, backoff_max: float):
    """
    Establish and maintain WebSocket connection to Vault events endpoint.
    
    Args:
        queue: asyncio queue for sending events to ansible-rulebook
        url: Complete WebSocket URL for Vault events subscription
        headers: HTTP headers including authentication
        ping_interval: Seconds between WebSocket ping frames
        verify_ssl: Whether to verify SSL certificates
        backoff_initial: Initial reconnection delay in seconds
        backoff_max: Maximum reconnection delay in seconds
    """
    # Configure SSL context for secure connections
    ssl_ctx = None
    if url.startswith("wss://"):
        ssl_ctx = ssl.create_default_context()
        if not verify_ssl:
            # Disable SSL verification for development environments
            ssl_ctx.check_hostname = False
            ssl_ctx.verify_mode = ssl.CERT_NONE

    # Exponential backoff for reconnection attempts
    backoff = backoff_initial
    
    while True:
        try:
            # Establish WebSocket connection with proper headers
            async with connect(url, additional_headers=headers,
                               ping_interval=ping_interval, ssl=ssl_ctx) as ws:
                log.info("Connected to Vault WebSocket: %s", url)
                backoff = backoff_initial  # Reset backoff on successful connection
                
                # Process incoming messages from Vault
                async for msg in ws:
                    try:
                        # Parse JSON event data from Vault
                        event = json.loads(msg)
                        log.debug("Received Vault event: %s", event.get('event_type', 'unknown'))
                    except json.JSONDecodeError as e:
                        # Handle malformed JSON gracefully
                        log.warning("Failed to parse JSON message: %s", e)
                        event = {"raw": msg, "error": "json_decode_failed"}
                    except Exception as e:
                        # Handle any other parsing errors
                        log.error("Unexpected error parsing message: %s", e)
                        event = {"raw": msg, "error": str(e)}
                    
                    # Forward event to ansible-rulebook queue
                    await queue.put(event)
                    
        except asyncio.CancelledError:
            # Handle graceful shutdown
            log.info("WebSocket connection cancelled, shutting down")
            raise
        except Exception as e:
            # Handle connection errors with exponential backoff
            log.warning("WebSocket disconnected: %s; reconnecting in %.1fs", e, backoff)
            await asyncio.sleep(backoff)
            backoff = min(backoff * 2, backoff_max)  # Exponential backoff with cap


def _build_event_url(vault_addr: str, event_paths: List[str]) -> str:
    """
    Construct the WebSocket URL for Vault event subscription.
    
    Args:
        vault_addr: Base Vault server URL (http/https)
        event_paths: List of event paths to subscribe to
        
    Returns:
        Complete WebSocket URL for event subscription
    """
    # Convert HTTP(S) to WebSocket scheme
    if vault_addr.startswith("https://"):
        ws_url = vault_addr.replace("https://", "wss://")
    else:
        ws_url = vault_addr.replace("http://", "ws://")
    
    # Join multiple event paths with comma separation
    paths = ",".join(event_paths)
    
    # Build complete event subscription URL
    event_url = f"{ws_url}/v1/sys/events/subscribe/{paths}?json=true"
    log.info("Built event URL: %s", event_url)
    
    return event_url


async def main(queue: Any, args: Dict[str, Any]):
    """
    Main entry point for the Vault events plugin.
    
    This function is called by ansible-rulebook to start the event source.
    It processes configuration parameters and initiates the WebSocket connection.
    
    Args:
        queue: asyncio queue for sending events to ansible-rulebook
        args: Configuration dictionary from the rulebook YAML
        
    Expected args:
        vault_addr: Vault server URL (e.g., "http://127.0.0.1:8200")
        vault_token: Vault authentication token
        event_paths: List of event paths to subscribe to
        verify_ssl: Whether to verify SSL certificates (default: True)
        ping_interval: WebSocket ping interval in seconds (default: 20)
        backoff_initial: Initial reconnection delay (default: 1.0)
        backoff_max: Maximum reconnection delay (default: 30.0)
        namespace: Optional Vault namespace
        headers: Optional additional HTTP headers
    """
    log.info("Starting Vault WebSocket event source plugin")
    
    # Extract and validate required parameters
    vault_addr = args.get("vault_addr")
    if not vault_addr:
        raise ValueError("vault_addr parameter is required")
    
    vault_token = args.get("vault_token")
    if not vault_token:
        raise ValueError("vault_token parameter is required")
    
    event_paths = args.get("event_paths", ["kv-v2/data-*"])
    if isinstance(event_paths, str):
        event_paths = [event_paths]  # Convert single string to list
    
    log.info("Vault Address: %s", vault_addr)
    log.info("Event Paths: %s", event_paths)
    
    # Build the complete WebSocket URL
    url = _build_event_url(vault_addr, event_paths)
    
    # Prepare HTTP headers for authentication
    headers: Dict[str, str] = {}
    headers["X-Vault-Token"] = vault_token
    
    # Add optional Vault namespace header
    if args.get("namespace"):
        headers["X-Vault-Namespace"] = args["namespace"]
        log.info("Using Vault namespace: %s", args["namespace"])
    
    # Add any additional custom headers
    custom_headers = args.get("headers", {})
    if custom_headers:
        headers.update(custom_headers)
        log.info("Added custom headers: %s", list(custom_headers.keys()))
    
    # Extract connection parameters with defaults
    verify_ssl = bool(args.get("verify_ssl", True))
    ping_interval = int(args.get("ping_interval", 20))
    backoff_initial = float(args.get("backoff_initial", 1.0))
    backoff_max = float(args.get("backoff_max", 30.0))
    
    log.info("Connection settings - SSL verify: %s, Ping interval: %ds", 
             verify_ssl, ping_interval)
    
    # Start the WebSocket stream
    await _stream(
        queue=queue,
        url=url,
        headers=headers,
        ping_interval=ping_interval,
        verify_ssl=verify_ssl,
        backoff_initial=backoff_initial,
        backoff_max=backoff_max,
    )